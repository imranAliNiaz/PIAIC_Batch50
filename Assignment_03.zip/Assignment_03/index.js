"use strict";
//        ----------------------ASSIGNMENT NO 3--------------------------
//        -----------------------QUESTION NO 1---------------------------
function insertValueAtIndex(array, index, value) {
    // Check if the index is within the bounds of the array
    if (index < 0 || index > array.length) {
        throw new Error("Index out of bounds");
    }
    // Use splice to insert the value at the specified index
    array.splice(index, 0, value);
    return array;
}
const originalArray = [1, 2, 3, 4];
const modifiedArray = insertValueAtIndex(originalArray, 3, 300);
console.log(modifiedArray);
//         ------------------------QUESTION NO 2---------------------------
//--Implement a simple shopping cart program using an array. Create functions to add items, remove items, and update quantities using the splice method. Print the cart's contents after each operation
var Shopping_Cart = ["5-Excel Sirf", "5kg-Sugar", "10_Dozen-Egg"];
function Add_Item(Shopping_Cart, index, New_Thing) {
    if (index >= 0 && index < Shopping_Cart.length) {
        Shopping_Cart.splice(index, 0, New_Thing);
        console.log(Shopping_Cart);
    }
    else {
        console.log("Invalid Index");
    }
}
function Remove_Item(Shopping_Cart, index) {
    if (index >= 0 && index < Shopping_Cart.length) {
        Shopping_Cart.splice(index, 1);
        console.log(Shopping_Cart);
    }
    else {
        console.log("Invalid Index");
    }
}
function Update_Item(Shopping_Cart, index, New_Thing) {
    if (index >= 0 && index < Shopping_Cart.length) {
        Shopping_Cart.splice(index, 1, New_Thing);
        console.log(Shopping_Cart);
    }
    else {
        console.log("Invalid Index");
    }
}
// Implement Function 
Add_Item(Shopping_Cart, 0, "5kg-Rice");
Remove_Item(Shopping_Cart, 1);
Update_Item(Shopping_Cart, 2, "1_Dozen-Egg");
console.log(); // For New Line 
//         ------------------------QUESTION NO 3---------------------------
// - Write a program that uses a while loop to print the first 25 integers.
var count = 1;
while (count <= 25) {
    console.log(count);
    count++;
}
console.log(); // For New Line 
//         ------------------------QUESTION NO 4---------------------------
//-- - Write a program that uses a while loop to print the first 10 even numbers.
var i = 1;
var count = 0;
while (i <= 50) {
    if (i % 2 == 0) {
        count++;
        console.log(count + "  First Ten Even Number are: " + i);
        if (count == 10) {
            break;
        }
    }
    i++;
}
console.log(); // For New Line
//         ------------------------QUESTION NO 5---------------------------
//--Create a function that takes a positive integer as parameter and uses a while loop to calculate and return the factorial of that number.
function CalculateFactorial(value) {
    if (value >= 0) {
        var i = 1;
        var fact = 1;
        while (i <= value) {
            fact = fact * i;
            i++;
        }
        return fact;
    }
    else {
        return -1;
    }
}
var result = CalculateFactorial(8);
if (result >= 0) {
    console.log("Your Answer Of Factorial Is : " + result);
}
else {
    console.log("Kindly Enter Positive Number!.");
}
console.log(); // For New Line 
//         ------------------------QUESTION NO 6---------------------------
//-- Write a program having an array of numbers if the number is negative it should remove the negative number from the array.
var array = [12, 13, -2, 12, -3, 31];
var SizeofArray = array.length;
var i = 0;
while (i < SizeofArray) {
    if (array[i] < 0) {
        array.splice(i, 1);
    }
    i++;
}
console.log("Array After Removing Negative Number : " + array);
console.log(); // For New Line 
//         ------------------------QUESTION NO 7---------------------------
//---Create a function that takes an array of numbers as parameter. Use a while loop to calculate and return the sum of all the numbers in the array
var array = [1, 2, 3, 4, 5];
function Sum_of_Array(array) {
    var i = 0;
    var sum = 0;
    var sizearray = array.length;
    while (i < sizearray) {
        sum = sum + array[i];
        i += 1;
    }
    return sum;
}
var TotalSum = Sum_of_Array(array);
console.log("Sum Of Array " + TotalSum);
console.log(); // For New Line 
//         ------------------------QUESTION NO 8---------------------------
//--Implement a program that takes a list of temperatures in Celsius as input from the user. Convert each temperature to Fahrenheit using the formula F = (C * 9/5) + 32 and store the converted temperatures in an array. Use a while loop to perform the conversion for each temperature
var tempInCelcius = [40, 38, 39, 30, 25];
var tempInFahrenheit = [];
var i = 0;
while (i < tempInCelcius.length) {
    tempInFahrenheit[i] = (tempInCelcius[i] * 9 / 5) + 32;
    i++;
}
console.log("Array Of Temp in Celcius " + tempInCelcius);
console.log("Array Of Temp in Cel To Fahrenheit " + tempInFahrenheit);
console.log(); // For New Line 
