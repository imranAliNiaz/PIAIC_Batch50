"use strict";
//-----------------------------------Advanced Assignment----------------------------------------------
//-----------------------------------Question No 1----------------------------------------------------
//--Personal Message: Store a person’s name in a variable, and print a message to that person. Your message should be simple, such as, “Hello Eric, would you like to learn some Python today?”
// Store the person's name in a variable
var person_Name = "Imran Ali Niaz";
// Create a message
var myMessage = `Hello ${person_Name}, would you like to learn some Python today?`;
// Print the message
console.log(myMessage);
//-----------------------------------Question No 2----------------------------------------------------
//--Name Cases: Store a person’s name in a variable, and then print that person’s name in lowercase, uppercase, and titlecase.
// Store the person's name in a variable
var myName = "Imran Ali Niaz";
// Convert the name to lowercase
var toLowerCaseName = myName.toLowerCase();
// Convert the name to uppercase
var toUpperCaseName = myName.toUpperCase();
// Convert the name to titlecase
function toTitleCaseName(str) {
    return str.replace(/\w\S*/g, (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());
}
var titleCase = toTitleCaseName(myName);
// Print the different cases
console.log("Original Name: " + myName);
console.log("Lowercase Name: " + toLowerCaseName);
console.log("Uppercase Name: " + toUpperCaseName);
console.log("Titlecase Name: " + titleCase);
//-----------------------------------Question No 3----------------------------------------------------
//--Famous Quote: Find a quote from a famous person you admire. Print the quote and the name of its author. Your output should look something like the following, including the quotation marks:
//--Albert Einstein once said, “A person who never made a mistake never tried anything new.”
// Define the quote and its author
const famousQuote = "A person who never made a mistake never tried anything new.";
const quoteAuthor = "Albert Einstein";
// Print the quote and its author
console.log(`${quoteAuthor} once said, "${famousQuote}"`);
//-----------------------------------Question No 4------------------------------------------------------
//--Famous Quote 2: Repeat Exercise 4, but this time store the famous person’s name in a variable called famous_person. Then compose your message and store it in a new variable called message. Print your message.
// Store the famous person's name in a variable
var famous_person = "Albert Einstein";
// Define the quote
var myQuote = "A person who never made a mistake never tried anything new.";
// Compose the message
var quoteMessage = `${famous_person} once said, "${myQuote}"`;
// Print the message
console.log(quoteMessage);
//-----------------------------------Question No 5------------------------------------------------------
//--Stripping Names: Store a person’s name, and include some whitespace characters at the beginning and end of the name. Make sure you use each character combination, "\t" and "\n", at least once. Print the name once, so the whitespace around the name is displayed. Then print the name after striping the white spaces.
// Store the person's name with whitespace
var nameWithWhitespace = "\t  \n Imran Ali Niaz \t  \n";
// Print the name with whitespace
console.log("Name with Whitespace: ");
console.log(nameWithWhitespace);
// Strip the whitespace 
var strippedName = nameWithWhitespace.trim();
// Print the name after stripping whitespace
console.log("\nName after Stripping Whitespace: ");
console.log(strippedName);
//-----------------------------------Question No 6------------------------------------------------------
//--Number Eight: Write addition, subtraction, multiplication, and division operations that each result in the number 8. Be sure to enclose your operations in print statements to see the results.
// Addition
var additionResult = 5 + 3;
console.log("Addition: 5 + 3 =", additionResult);
// Subtraction
var subtractionResult = 15 - 7;
console.log("Subtraction: 15 - 7 =", subtractionResult);
// Multiplication
var multiplicationResult = 4 * 2;
console.log("Multiplication: 4 * 2 =", multiplicationResult);
// Division
var divisionResult = 16 / 2;
console.log("Division: 16 / 2 =", divisionResult);
//-----------------------------------Question No 7------------------------------------------------------
//--You should create four lines that look like this:
//console.log(5 + 3)
//Your output should simply be four lines with the number 8 appearing once on each line.
//-----------------------------------Question No 8------------------------------------------------------
//--Favorite Number: Store your favorite number in a variable. Then, using that variable, create a message that reveals your favorite number. Print that message.
// Store favorite number in a variable
var favoriteNumber = 32;
// Create a message 
const favNumMessage = `My favorite number is ${favoriteNumber}.`;
// Print the message
console.log(favNumMessage);
//-----------------------------------Question No 9------------------------------------------------------
//--Adding Comments: Choose two of the programs you’ve written, and add at least one comment to each. If you don’t have anything specific to write because your programs are too simple at this point, just add your name and the current date at the top of each program file. Then write one sentence describing what the program does.
//Program 1: Name Cases
// Store the person's name in a variable
var myPersonName = "Imran Ali Niaz";
// Convert the name to lowercase
var lowercaseName = myPersonName.toLowerCase();
// Convert the name to uppercase
var uppercaseName = myPersonName.toUpperCase();
// Convert the name to titlecase
function toTitleCase(str) {
    return str.replace(/\w\S*/g, (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());
}
var titlecaseName = toTitleCase(myPersonName);
// Print the different cases
console.log("Original Name: " + myPersonName);
console.log("Lowercase Name: " + lowercaseName);
console.log("Uppercase Name: " + uppercaseName);
console.log("Titlecase Name: " + titlecaseName);
//DESCRIPTION
//This program takes a person's name, converts it to lowercase, uppercase, and titlecase, and then prints the different name cases.
//Program 2: Famous Quote
// Define the quote and its author
const quote = "A person who never made a mistake never tried anything new.";
const author = "Albert Einstein";
// Print the quote and its author
console.log(`${author} once said, "${quote}"`);
//DESCRIPTION
//-----This program prints a famous quote by Albert Einstein along with its author.
//-----------------------------------Question No 10------------------------------------------------------
//--Names: Store the names of a few of your friends in a array called names. Print each person’s name by accessing each element in the list, one at a time.
// Store the names of friends in an array
const friendNames = ["Ali", "Fasih", "Zia", "Huzaifa", "Bilal"];
//print each person's name
for (let i = 0; i < friendNames.length; i++) {
    console.log("Friend " + (i + 1) + ": " + friendNames[i]);
}
//-----------------------------------Question No 11------------------------------------------------------
//--Greetings: Start with the array you used in Exercise 11, but instead of just printing each person’s name, print a message to them. The text of each message should be the same, but each message should be personalized with the person’s name.
// Store the names of your friends in an array
var names = ["Ali", "Fasih", "Zia", "Huzaifa", "Bilal"];
// Define the greeting message
const greetingMessage = "Hello, would you like to hang out today, ";
//print personalized messages
for (let i = 0; i < names.length; i++) {
    const personalizedMessage = greetingMessage + names[i] + "?";
    console.log(personalizedMessage);
}
//-----------------------------------Question No 12------------------------------------------------------
//--Your Own Array: Think of your favorite mode of transportation, such as a motorcycle or a car, and make a list that stores several examples. Use your list to print a series of statements about these items, such as “I would like to own a Honda motorcycle.”
// Create an array of different modes of transportation
var transportationModes = ["car", "motorcycle", "bicycle", "train", "bus"];
//print statements about each mode of transportation
for (let i = 0; i < transportationModes.length; i++) {
    var mode = transportationModes[i];
    console.log(`I would like to own a ${mode}.`);
}
//-----------------------------------Question No 13------------------------------------------------------
//--Guest List: If you could invite anyone, living or deceased, to dinner, who would you invite? Make a list that includes at least three people you’d like to invite to dinner. Then use your list to print a message to each person, inviting them to dinner.
// Create an array of people you'd like to invite to dinner
var myGuestList = ["Huzaifa Ahmad", "Fasih Ahmad Khan", "Zia-ur-Rahman"];
//Print invitation messages
for (let i = 0; i < myGuestList.length; i++) {
    var guestName = myGuestList[i];
    console.log(`Dear ${guestName}, you are cordially invited to dinner. We would be honored to have you join us.`);
}
//-----------------------------------Question No 14------------------------------------------------------
//--Changing Guest List: You just heard that one of your guests can’t make the dinner, so you need to send out a new set of invitations. You’ll have to think of someone else to invite.
//• Start with your program from Exercise 14. Add a print statement at the end of your program stating the name of the guest who can’t make it.
//• Modify your list, replacing the name of the guest who can’t make it with the name of the new person you are inviting.
//• Print a second set of invitation messages, one for each person who is still in your list.
// Create an array of people you'd like to invite to dinner
let guest_List = ["Huzaifa Ahmad", "Fasih Ahmad Khan", "Zia-ur-Rahman"];
// Print the name of the guest who can't make it
var guestCantMakeIt = "Fasih Ahmad Khan";
console.log(`${guestCantMakeIt} can't make it to the dinner.`);
// Find the index of the guest who can't make it
const indexOfGuestCantMakeIt = guest_List.indexOf(guestCantMakeIt);
if (indexOfGuestCantMakeIt !== -1) {
    // Replace the guest who can't make it with a new person
    guest_List[indexOfGuestCantMakeIt] = "Bilal";
}
// Print a second set of invitation messages for the updated list
console.log("\nSecond Set of Invitation Messages:");
for (let i = 0; i < guest_List.length; i++) {
    const guestName = guest_List[i];
    console.log(`Dear ${guestName}, you are cordially invited to dinner. We would be honored to have you join us.`);
}
//-----------------------------------Question No 15------------------------------------------------------
//--More Guests: You just found a bigger dinner table, so now more space is available. Think of three more guests to invite to dinner.
//• Start with your program from Exercise 15. Add a print statement to the end of your program informing people that you found a bigger dinner table.
//• Add one new guest to the beginning of your array.
//• Add one new guest to the middle of your array. • Use append() to add one new guest to the end of your list. • Print a new set of invitation messages, one for each person in your list.
// Create an array of people you'd like to invite to dinner
var guests = ["Huzaifa Ahmad", "Fasih Ahmad Khan", "Zia-ur-Rahman"];
// Print an announcement about the bigger dinner table
console.log("Good news! We found a bigger dinner table!");
// Add a new guest to the beginning of the array
guests.unshift("Haroon");
// Calculate the middle index of the array
var middleIndex = Math.floor(guests.length / 2);
// Add a new guest to the middle of the array
guests.splice(middleIndex, 0, "Fawad");
// Use push() to add a new guest to the end of the list
guests.push("Darwin");
// Print a new set of invitation messages for the updated list
console.log("\nNew Set of Invitation Messages:");
for (let i = 0; i < guests.length; i++) {
    var guestName = guests[i];
    console.log(`Dear ${guestName}, you are cordially invited to dinner. We would be honored to have you join us.`);
}
//-----------------------------------Question No 16------------------------------------------------------
//--Shrinking Guest List: You just found out that your new dinner table won’t arrive in time for the dinner, and you have space for only two guests.
//• Start with your program from Exercise 16. Add a new line that prints a message saying that you can invite only two people for dinner.
//• Remove guests from your list one at a time until only two names remain in your list. Each time you pop a name from your list, print a message to that person letting them know you’re sorry you can’t invite them to dinner.
//• Print a message to each of the two people still on your list, letting them know they’re still invited.
//• Remove the last two names from your list, so you have an empty list. Print your list to make sure you actually have an empty list at the end of your program.
// Create an array of people you'd like to invite to dinner
var ListOfGuest = ["Huzaifa Ahmad", "Fasih Ahmad Khan", "Zia-ur-Rahman", "Haroon", "Bilal"];
// Print a message announcing that only two people can be invited
console.log("Unfortunately, we can only invite two people for dinner.");
// Remove guests one at a time until only two names remain
while (ListOfGuest.length > 2) {
    var removedGuest = ListOfGuest.pop();
    console.log(`Sorry, ${removedGuest}, we can't invite you to dinner.`);
}
// Print a message to each of the two remaining guests
for (let i = 0; i < ListOfGuest.length; i++) {
    const guestName = ListOfGuest[i];
    console.log(`Dear ${guestName}, you are still invited to dinner.`);
}
// Remove the last two names to have an empty list
ListOfGuest.pop();
ListOfGuest.pop();
// Print the empty list to verify
console.log("\nGuest List at the End:", ListOfGuest);
//-----------------------------------Question No 17------------------------------------------------------
//--Seeing the World: Think of at least five places in the world you’d like to visit.
//• Store the locations in a array. Make sure the array is not in alphabetical order.
//• Print your array in its original order.
//• Print your array in alphabetical order without modifying the actual list.
//• Show that your array is still in its original order by printing it.
//• Print your array in reverse alphabetical order without changing the order of the original list.
//• Show that your array is still in its original order by printing it again.
//• Reverse the order of your list. Print the array to show that its order has changed.
//• Reverse the order of your list again. Print the list to show it’s back to its original order.
//• Sort your array so it’s stored in alphabetical order. Print the array to show that its order has been changed.
//• Sort to change your array so it’s stored in reverse alphabetical order. Print the list to show that its order has changed.
// Create an array of travel destinations
var destinations = ["Tokyo", "Paris", "New York", "Sydney", "Rome"];
// Print the original array
console.log("Original Order:", destinations);
// Print the array in alphabetical order without modifying the original list
console.log("\nAlphabetical Order:", [...destinations].sort());
// Show that the original array is still in its original order
console.log("\nOriginal Order (unchanged):", destinations);
// Print the array in reverse alphabetical order without modifying the original list
console.log("\nReverse Alphabetical Order:", [...destinations].sort().reverse());
// Show that the original array is still in its original order
console.log("\nOriginal Order (unchanged):", destinations);
// Reverse the order of the list
destinations = destinations.reverse();
// Print the array to show its order has changed
console.log("\nReversed Order:", destinations);
// Reverse the order of the list again to get it back to the original order
destinations = destinations.reverse();
// Print the array to show it's back to its original order
console.log("\nOriginal Order (restored):", destinations);
// Sort the array to store it in alphabetical order
destinations.sort();
// Print the array to show its order has been changed
console.log("\nSorted in Alphabetical Order:", destinations);
// Sort the array to store it in reverse alphabetical order
destinations.sort().reverse();
// Print the array to show its order has been changed
console.log("\nSorted in Reverse Alphabetical Order:", destinations);
//-----------------------------------Question No 18------------------------------------------------------
//--Dinner Guests: Working with one of the programs from Exercises 14 through 18, print a message indicating the number of people you are inviting to dinner.
// Create an array of people you'd like to invite to dinner
var guestList = ["Huzaifa Ahmad", "Fasih Ahmad Khan", "Zia-ur-Rahman", "Haroon", "Bilal"];
// Print a message indicating the number of people you are inviting to dinner
var numberOfGuests = guestList.length;
console.log(`You are inviting ${numberOfGuests} people to dinner.`);
//-----------------------------------Question No 19------------------------------------------------------
//--Think of something you could store in a array. For example, you could make a list of mountains, rivers, countries, cities, languages, or anything else you’d like. Write a program that creates a list containing these items.
// Create an array of countries
var countries = [
    "United States",
    "Canada",
    "United Kingdom",
    "Australia",
    "Germany",
    "France",
    "Japan",
    "India",
    "Brazil",
    "South Africa"
];
// Print the list of countries
console.log("List of Countries:");
for (let i = 0; i < countries.length; i++) {
    console.log(countries[i]);
}
//-----------------------------------Question No 20------------------------------------------------------
//--They think of something you could store in a TypeScript Object. Write a program that creates Objects containing these items.
// Create objects containing information about fruits
var apple = {
    name: "Apple",
    color: "Red",
    taste: "Sweet",
    origin: "Various",
};
var banana = {
    name: "Banana",
    color: "Yellow",
    taste: "Sweet",
    origin: "Tropical regions",
};
var orange = {
    name: "Orange",
    color: "Orange",
    taste: "Sweet and tangy",
    origin: "Various",
};
// Print information about each fruit
console.log("Fruit Information:");
console.log("Apple:", apple);
console.log("Banana:", banana);
console.log("Orange:", orange);
//-----------------------------------Question No 21------------------------------------------------------
//--Intentional Error: If you haven’t received an array index error in one of your programs yet, try to make one happen. Change an index in one of your programs to produce an index error. Make sure you correct the error before closing the program.
// Create an array 
var myArray = [1, 2, 3, 4, 5];
// Try to access an element at an invalid index
var invalidIndex = 15;
try {
    var element = myArray[invalidIndex];
    console.log(`Element at index ${invalidIndex}: ${element}`);
}
catch (error) {
    // Handle the error
    console.error(`Error: ${error.message}`);
}
// Correct error by accessing a valid index
var validIndex = 2;
var validElement = myArray[validIndex];
console.log(`Element at index ${validIndex}: ${validElement}`);
//-----------------------------------Question No 22------------------------------------------------------
//--Conditional Tests: Write a series of conditional tests. Print a statement describing each test and your prediction for the results of each test. Your code should look something like this:
//let car = 'subaru';
//console.log("Is car == 'subaru'? I predict True.")
//console.log(car == 'subaru')
//• Look closely at your results, and make sure you understand why each line evaluates to True or False.
//• Create at least 10 tests. Have at least 5 tests evaluate to True and another 5 tests evaluate to False.
let car = 'subaru';
// Test 1: Check if car is equal to 'subaru'
console.log("Is car == 'subaru'? I predict True.");
console.log(car == 'subaru'); // True
// Test 2: Check if car is equal to 'honda'
console.log("Is car == 'honda'? I predict False.");
console.log(car == 'honda'); // False
// Test 3: Check if car is not equal to 'toyota'
console.log("Is car != 'toyota'? I predict True.");
console.log(car != 'toyota'); // True
// Test 4: Check if car is not equal to 'subaru'
console.log("Is car != 'subaru'? I predict False.");
console.log(car != 'subaru'); // False
// Test 5: Check if car is 'Subaru' (case-sensitive)
console.log("Is car === 'Subaru'? I predict False.");
console.log(car === 'Subaru'); // False
// Test 6: Check if car is 'subaru' (case-sensitive)
console.log("Is car === 'subaru'? I predict True.");
console.log(car === 'subaru'); // True
// Test 7: Check if car is not 'honda' (case-insensitive)
console.log("Is car.toLowerCase() != 'honda'? I predict True.");
console.log(car.toLowerCase() != 'honda'); // True
// Test 8: Check if car is not 'Subaru' (case-insensitive)
console.log("Is car.toLowerCase() === 'subaru'? I predict True.");
console.log(car.toLowerCase() === 'subaru'); // True
// Test 9: Check if car contains the letter 'u'
console.log("Does car include 'u'? I predict True.");
console.log(car.includes('u')); // True
// Test 10: Check if car contains the letter 'x'
console.log("Does car include 'x'? I predict False.");
console.log(car.includes('x')); // False
//-----------------------------------Question No 23------------------------------------------------------
//--More Conditional Tests: You don’t have to limit the number of tests you create to 10. If you want to try more comparisons, write more tests. Have at least one True and one False result for each of the following:
//• Tests for equality and inequality with strings
//• Tests using the lower case function
//• Numerical tests involving equality and inequality, greater than and less than, greater than or equal to, and less than or equal to
//• Tests using "and" and "or" operators
//• Test whether an item is in a array
//• Test whether an item is not in a array
// String equality and inequality tests
var fruit = 'apple';
console.log("Is fruit equal to 'apple'? I predict True.");
console.log(fruit == 'apple'); // True
console.log("Is fruit not equal to 'banana'? I predict True.");
console.log(fruit != 'banana'); // True
console.log("Is fruit equal to 'Apple'? I predict False (case-sensitive).");
console.log(fruit === 'Apple'); // False
// Lowercase function tests
const city = 'New York';
console.log("Is city lowercase equal to 'new york'? I predict True.");
console.log(city.toLowerCase() == 'new york'); // True
// Numerical tests
const num1 = 10;
const num2 = 5;
console.log("Is num1 greater than num2? I predict True.");
console.log(num1 > num2); // True
console.log("Is num1 less than num2? I predict False.");
console.log(num1 < num2); // False
console.log("Is num1 greater than or equal to num2? I predict True.");
console.log(num1 >= num2); // True
console.log("Is num1 less than or equal to num2? I predict False.");
console.log(num1 <= num2); // False
// Logical "and" and "or" operator tests
const sunny = true;
const warm = false;
console.log("Is it sunny and warm? I predict False.");
console.log(sunny && warm); // False
console.log("Is it sunny or warm? I predict True.");
console.log(sunny || warm); // True
// Array membership tests
const colors = ['red', 'green', 'blue'];
console.log("Is 'green' in the colors array? I predict True.");
console.log(colors.includes('green')); // True
console.log("Is 'yellow' not in the colors array? I predict True.");
console.log(!colors.includes('yellow')); // True
//-----------------------------------Question No 24------------------------------------------------------
//--Alien Colors #1: Imagine an alien was just shot down in a game. Create a variable called alien_color and assign it a value of 'green', 'yellow', or 'red'.
//• Write an if statement to test whether the alien’s color is green. If it is, print a message that the player just earned 5 points.
//• Write one version of this program that passes the if test and another that fails. (The version that fails will have no output.)
//Passing Version
// Passing version
var alien_color_pass = 'green';
if (alien_color_pass === 'green') {
    console.log("Player just earned 5 points.");
}
// Failing version
var alien_color_fail = 'red';
if (alien_color_fail === 'green') {
    console.log("Player just earned 5 points.");
}
//-----------------------------------Question No 25------------------------------------------------------
//--Alien Colors #2: Choose a color for an alien as you did in Exercise 25, and write an if-else chain.
//• If the alien’s color is green, print a statement that the player just earned 5 points for shooting the alien.
//• If the alien’s color isn’t green, print a statement that the player just earned 10 points.
//• Write one version of this program that runs the if block and another that runs the else block.
//Version 1 (Runs the if block - Alien color is green)
var alien_Color_V1 = 'green';
if (alien_Color_V1 === 'green') {
    console.log("Congratulations! You just earned 5 points for shooting the green alien.");
}
else {
    console.log("Congratulations! You just earned 10 points for shooting an alien that isn't green.");
}
//Version 2 (Runs the else block - Alien color isn't green)
var alien_Color_V2 = 'red';
if (alien_Color_V2 === 'green') {
    console.log("Congratulations! You just earned 5 points for shooting the green alien.");
}
else {
    console.log("Congratulations! You just earned 10 points for shooting an alien that isn't green.");
}
//-----------------------------------Question No 26------------------------------------------------------
//--Alien Colors #3: Turn your if-else chain from Exercise 5-4 into an if-else chain.
//• If the alien is green, print a message that the player earned 5 points.
//• If the alien is yellow, print a message that the player earned 10 points.
//• If the alien is red, print a message that the player earned 15 points.
//• Write three versions of this program, making sure each message is printed for the appropriate color alien.
//Version 1 (Green Alien - 5 points)
var alien_Color_Green = 'green';
if (alien_Color_Green === 'green') {
    console.log("Congratulations! You just earned 5 points for shooting the green alien.");
}
else if (alien_Color_Green === 'yellow') {
    console.log("Congratulations! You just earned 10 points for shooting the yellow alien.");
}
else if (alien_Color_Green === 'red') {
    console.log("Congratulations! You just earned 15 points for shooting the red alien.");
}
//Version 2 (Yellow Alien - 10 points)
var alien_Color_Yellow = 'yellow';
if (alien_Color_Yellow === 'green') {
    console.log("Congratulations! You just earned 5 points for shooting the green alien.");
}
else if (alien_Color_Yellow === 'yellow') {
    console.log("Congratulations! You just earned 10 points for shooting the yellow alien.");
}
else if (alien_Color_Yellow === 'red') {
    console.log("Congratulations! You just earned 15 points for shooting the red alien.");
}
//Version 3 (Red Alien - 15 points)
var alien_Color_Red = 'red';
if ((alien_Color_Red === 'green')) {
    console.log("Congratulations! You just earned 5 points for shooting the green alien.");
}
else if ((alien_Color_Red === 'yellow')) {
    console.log("Congratulations! You just earned 10 points for shooting the yellow alien.");
}
else if ((alien_Color_Red === 'red')) {
    console.log("Congratulations! You just earned 15 points for shooting the red alien.");
}
//-----------------------------------Question No 27------------------------------------------------------
//--Stages of Life: Write an if-else chain that determines a person’s stage of life. Set a value for the variable age, and then:
//• If the person is less than 2 years old, print a message that the person is a baby.
//• If the person is at least 2 years old but less than 4, print a message that the person is a toddler.
//• If the person is at least 4 years old but less than 13, print a message that the person is a kid.
//• If the person is at least 13 years old but less than 20, print a message that the person is a teenager.
//• If the person is at least 20 years old but less than 65, print a message that the person is an adult.
//• If the person is age 65 or older, print a message that the person is an elder.
var age = 35;
if (age < 2) {
    console.log("The person is a baby.");
}
else if (age >= 2 && age < 4) {
    console.log("The person is a toddler.");
}
else if (age >= 4 && age < 13) {
    console.log("The person is a kid.");
}
else if (age >= 13 && age < 20) {
    console.log("The person is a teenager.");
}
else if (age >= 20 && age < 65) {
    console.log("The person is an adult.");
}
else {
    console.log("The person is an elder.");
}
//-----------------------------------Question No 28------------------------------------------------------
//--Favorite Fruit: Make a array of your favorite fruits, and then write a series of independent if statements that check for certain fruits in your array.
//• Make a array of your three favorite fruits and call it favorite_fruits.
//• Write five if statements. Each should check whether a certain kind of fruit is in your array. If the fruit is in your array, the if block should print a statement, such as You really like bananas!
var favorite_fruits = ['apple', 'banana', 'strawberry'];
if (favorite_fruits.includes('apple')) {
    console.log("You really like apples!");
}
if (favorite_fruits.includes('banana')) {
    console.log("You really like bananas!");
}
if (favorite_fruits.includes('strawberry')) {
    console.log("You really like strawberries!");
}
if (favorite_fruits.includes('orange')) {
    console.log("You really like oranges!");
}
if (favorite_fruits.includes('kiwi')) {
    console.log("You really like kiwis!");
}
//-----------------------------------Question No 29------------------------------------------------------
//--Hello Admin: Make a array of five or more usernames, including the name 'admin'. Imagine you are writing code that will print a greeting to each user after they log in to a website. Loop through the array, and print a greeting to each user:
//• If the username is 'admin', print a special greeting, such as Hello admin, would you like to see a status report?
//• Otherwise, print a generic greeting, such as Hello Eric, thank you for logging in again.
var userNames = ['admin', 'Ali', 'Fasih', 'Huzaifa', 'Bilal'];
for (var username of userNames) {
    if (username === 'admin') {
        console.log("Hello admin, would you like to see a status report?");
    }
    else {
        console.log(`Hello ${username}, thank you for logging in again.`);
    }
}
//-----------------------------------Question No 30------------------------------------------------------
//--No Users: Add an if test to Exercise 28 to make sure the list of users is not empty.
//• If the list is empty, print the message We need to find some users!
//• Remove all of the usernames from your array, and make sure the correct message is printed.
let usernames = ['admin', 'Ali', 'Fasih', 'Huzaifa', 'Bilal'];
if (usernames.length === 0) {
    console.log("We need to find some users!");
}
else {
    for (var username of usernames) {
        if (username === 'admin') {
            console.log("Hello admin, would you like to see a status report?");
        }
        else {
            console.log(`Hello ${username}, thank you for logging in again.`);
        }
    }
}
// Remove all usernames to test the "empty list" condition
usernames = [];
if (usernames.length === 0) {
    console.log("We need to find some users!");
}
//-----------------------------------Question No 31------------------------------------------------------
//--Checking Usernames: Do the following to create a program that simulates how websites ensure that everyone has a unique username.
//• Make a list of five or more usernames called current_users.
//• Make another list of five usernames called new_users. Make sure one or two of the new usernames are also in the current_users list.
//• Loop through the new_users list to see if each new username has already been used. If it has, print a message that the person will need to enter a new username. If a username has not been used, print a message saying that the username is available.
//• Make sure your comparison is case insensitive. If 'John' has been used, 'JOHN' should not be accepted.
// List of current users
const current_users = ['admin', 'Ali', 'Fasih', 'Huzaifa', 'Bilal'];
// List of new users
const new_users = ['Ali', 'Fasih', 'Sara', 'Haroon', 'Aaniq'];
// Function to check if a username is already used 
function isUsernameTaken(username) {
    return current_users.some((user) => user.toLowerCase() === username.toLowerCase());
}
// Loop through new_users to check uniqueness
for (const newUsername of new_users) {
    if (isUsernameTaken(newUsername)) {
        console.log(`Sorry, the username '${newUsername}' is already taken. Please choose a different one.`);
    }
    else {
        console.log(`Congratulations, the username '${newUsername}' is available.`);
    }
}
//-----------------------------------Question No 32------------------------------------------------------
//--Ordinal Numbers: Ordinal numbers indicate their position in a array, such as 1st or 2nd. Most ordinal numbers end in th, except 1, 2, and 3.
//• Store the numbers 1 through 9 in a array.
//• Loop through the array.
//• Use an if-else chain inside the loop to print the proper ordinal ending for each number. Your output should read "1st 2nd 3rd 4th 5th 6th 7th 8th 9th", and each result should be on a separate line.
var numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9];
for (var number of numbers) {
    let ordinal;
    if (number === 1) {
        ordinal = '1st';
    }
    else if (number === 2) {
        ordinal = '2nd';
    }
    else if (number === 3) {
        ordinal = '3rd';
    }
    else if (number >= 4 && number <= 20) {
        ordinal = `${number}th`;
    }
    else {
        // Handle numbers greater than 20
        var lastDigit = number % 10;
        switch (lastDigit) {
            case 1:
                ordinal = `${number}st`;
                break;
            case 2:
                ordinal = `${number}nd`;
                break;
            case 3:
                ordinal = `${number}rd`;
                break;
            default:
                ordinal = `${number}th`;
                break;
        }
    }
    console.log(ordinal);
}
//-----------------------------------Question No 33------------------------------------------------------
//--Pizzas: Think of at least three kinds of your favorite pizza. Store these pizza names in a array, and then use a for loop to print the name of each pizza.
//• Modify your for loop to print a sentence using the name of the pizza instead of printing just the name of the pizza. For each pizza you should have one line of output containing a simple statement like I like pepperoni pizza.
//• Add a line at the end of your program, outside the for loop, that states how much you like pizza. The output should consist of three or more lines about the kinds of pizza you like and then an additional sentence, such as I really love pizza!
// Array of favorite pizza names
var favoritePizzas = ['Pepperoni', 'Margherita', 'BBQ Chicken'];
// Print the names of each pizza
console.log('My favorite pizzas:');
for (var pizza of favoritePizzas) {
    console.log(pizza);
}
// Print a sentence about each pizza
console.log('\nDescription of my favorite pizzas:');
for (var pizza of favoritePizzas) {
    console.log(`I like ${pizza} pizza.`);
}
// Add a line about how much you like pizza
console.log('\nI really love pizza!');
//-----------------------------------Question No 34------------------------------------------------------
//--Animals: Think of at least three different animals that have a common characteristic. Store the names of these animals in a list, and then use a for loop to print out the name of each animal. • Modify your program to print a statement about each animal, such as A dog would make a great pet. • Add a line at the end of your program stating what these animals have in common. You could print a sentence such as Any of these animals would make a great pet!
var animals = ['Dog', 'Cat', 'Rabbit'];
for (var animal of animals) {
    console.log(`A ${animal} would make a great pet.`);
}
console.log("Any of these animals would make a great pet!");
//-----------------------------------Question No 35------------------------------------------------------
//--T-Shirt: Write a function called make_shirt() that accepts a size and the text of a message that should be printed on the shirt. The function should print a sentence summarizing the size of the shirt and the message printed on it. Call the function.
// Define the make_shirt function
function makeShirt(size, message) {
    console.log(`A ${size}-sized shirt will be printed with the message: "${message}"`);
}
// Call the function with different arguments
makeShirt('Medium', 'Hello World!');
makeShirt('Large', 'I Love TypeScript!');
//-----------------------------------Question No 36------------------------------------------------------
//--Large Shirts: Modify the make_shirt() function so that shirts are large by default with a message that reads I love TypeScript. Make a large shirt and a medium shirt with the default message, and a shirt of any size with a different message.
// Define the make_shirt function with default values
function make_shirt(size = 'Large', message = 'I love TypeScript') {
    console.log(`A ${size}-sized shirt will be printed with the message: "${message}"`);
}
// Create shirts with default and custom messages
make_shirt(); // Large shirt with default message
make_shirt('Medium'); // Medium shirt with default message
make_shirt('Small', 'Custom message for a Small shirt'); // Small shirt with a custom message
//-----------------------------------Question No 37------------------------------------------------------
//--Cities: Write a function called describe_city() that accepts the name of a city and its country. The function should print a simple sentence, such as Karachi is in Pakistan. Give the parameter for the country a default value. Call your function for three different cities, at least one of which is not in the default country.
// Define the describe_city function with a default country value
function describe_city(city, country = 'Unknown') {
    console.log(`${city} is in ${country}.`);
}
// Call the function for three different cities
describe_city('Karachi', 'Pakistan'); // Karachi is in Pakistan
describe_city('Paris', 'France'); // Paris is in France
describe_city('Sydney'); // Sydney is in Unknown (default)
//-----------------------------------Question No 38------------------------------------------------------
//--City Names: Write a function called city_country() that takes in the name of a city and its country. The function should return a string formatted like this:
//"Lahore, Pakistan"
//Call your function with at least three city-country pairs, and print the value that’s returned.
function city_country(city, country) {
    return `${city}, ${country}`;
}
// Calling the function with city-country pairs
const city1 = city_country('Lahore', 'Pakistan');
const city2 = city_country('New York', 'USA');
const city3 = city_country('Paris', 'France');
// Printing the formatted strings
console.log(city1); // This will print: Lahore, Pakistan
console.log(city2); // This will print: New York, USA
console.log(city3); // This will print: Paris, France
//-----------------------------------Question No 39------------------------------------------------------
//--Album: Write a function called make_album() that builds a Object describing a music album. The function should take in an artist name and an album title, and it should return a Object containing these two pieces of information. Use the function to make three dictionaries representing different albums. Print each return value to show that Objects are storing the album information correctly. Add an optional parameter to make_album() that allows you to store the number of tracks on an album. If the calling line includes a value for the number of tracks, add that value to the album’s Object. Make at least one new function call that includes the number of tracks on an album.
function make_album(artist, title, tracks) {
    const album = {
        artist: artist,
        title: title,
    };
    if (tracks !== undefined) {
        album.tracks = tracks;
    }
    return album;
}
// Creating album objects using the make_album function
const album1 = make_album('Artist1', 'Album1');
const album2 = make_album('Artist2', 'Album2', 12); // Example with a specified number of tracks
const album3 = make_album('Artist3', 'Album3');
// Printing album information
console.log(album1); // Object { artist: 'Artist1', title: 'Album1' }
console.log(album2); // Object { artist: 'Artist2', title: 'Album2', tracks: 12 }
console.log(album3); // Object { artist: 'Artist3', title: 'Album3' }
//-----------------------------------Question No 40------------------------------------------------------
//--Magicians: Make a array of magician’s names. Pass the array to a function called show_magicians(), which prints the name of each magician in the array.
function showMagicians(magicians) {
    for (const magician of magicians) {
        console.log(magician);
    }
}
// Array of magician names
var magician_Names = ['David Copperfield', 'Houdini', 'Penn & Teller', 'Dynamo'];
// Calling the show_magicians function to print the magician names
showMagicians(magician_Names);
//-----------------------------------Question No 41------------------------------------------------------
//--Great Magicians: Start with a copy of your program from Exercise 39. Write a function called make_great() that modifies the array of magicians by adding the phrase the Great to each magician’s name. Call show_magicians() to see that the list has actually been modified.
function makeGreat(magicians) {
    const greatMagicians = [];
    for (var magician of magicians) {
        greatMagicians.push(`${magician} the Great`);
    }
    return greatMagicians;
}
function show_my_magicians(magicians) {
    for (var magician of magicians) {
        console.log(magician);
    }
}
// Array of magician names
var magician_Names = ['David Copperfield', 'Houdini', 'Penn & Teller', 'Dynamo'];
// Adding "the Great" to magician names
var great_Magicians = make_great(magician_Names);
// Calling the show_magicians function to print the updated magician names
show_magicians(great_Magicians);
//-----------------------------------Question No 42------------------------------------------------------
//--Unchanged Magicians: Start with your work from Exercise 40. Call the function make_great() with a copy of the array of magicians’ names. Because the original array will be unchanged, return the new array and store it in a separate array. Call show_magicians() with each array to show that you have one array of the original names and one array with the Great added to each magician’s name.
function make_great(magicians) {
    const greatMagicians = [];
    for (var magician of magicians) {
        greatMagicians.push(`${magician} the Great`);
    }
    return greatMagicians;
}
function show_magicians(magicians) {
    for (var magician of magicians) {
        console.log(magician);
    }
}
// Array of magician names
var magicianNames = ['David Copperfield', 'Houdini', 'Penn & Teller', 'Dynamo'];
// Create a copy of the magicianNames array
var originalMagicians = [...magicianNames];
// Adding "the Great" to magician names without modifying the original array
var greatMagicians = make_great(originalMagicians);
// Calling show_magicians with the original and modified arrays
console.log('Original Magicians:');
show_magicians(originalMagicians);
console.log('\nGreat Magicians:');
show_magicians(greatMagicians);
//-----------------------------------Question No 43------------------------------------------------------
//--Sandwiches: Write a function that accepts a array of items a person wants on a sandwich. The function should have one parameter that collects as many items as the function call provides, and it should print a summary of the sandwich that is being ordered. Call the function three times, using a different number of arguments each time.
function orderSandwich(...items) {
    if (items.length === 0) {
        console.log('You ordered an empty sandwich. Please select some items.');
    }
    else {
        console.log('Sandwich Summary:');
        for (const item of items) {
            console.log(`- ${item}`);
        }
        console.log('Enjoy your sandwich!\n');
    }
}
// Call the function 
orderSandwich('Turkey', 'Lettuce', 'Tomato', 'Mayo');
orderSandwich('Ham', 'Swiss Cheese', 'Mustard');
orderSandwich();
//-----------------------------------Question No 44------------------------------------------------------
//--Cars: Write a function that stores information about a car in a Object. The function should always receive a manufacturer and a model name. It should then accept an arbitrary number of keyword arguments. Call the function with the required information and two other name-value pairs, such as a color or an optional feature. Print the Object that’s returned to make sure all the information was stored correctly.
function storeCarInfo(manufacturer, model, ...options) {
    const car = {
        manufacturer,
        model,
    };
    for (const [key, value] of options) {
        car[key] = value;
    }
    return car;
}
// Call the function with required and optional information
const carInfo = storeCarInfo('Toyota', 'Camry', ['color', 'Blue'], ['features', ['GPS', 'Sunroof']]);
// Print the car object
console.log(carInfo);
//-----------------------------------END OF ASSIGNMENT----------------------------------------------------//
