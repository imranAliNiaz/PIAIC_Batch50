class Person {
    name: string;
    age: number;
  
    constructor(name: string, age: number) {
      this.name = name;
      this.age = age;
    }
  
    introduce() {
      console.log(`My name is ${this.name} and I am ${this.age} years old.`);
    }
  }
  
  class Student extends Person {
    studentID: number;
  
    constructor(name: string, age: number, studentID: number) {
      super(name, age);
      this.studentID = studentID;
    }
  
    study() {
      console.log(`${this.name} is studying.`);
    }
  }
  
  class Teacher extends Person {
    employeeID: number;
  
    constructor(name: string, age: number, employeeID: number) {
      super(name, age);
      this.employeeID = employeeID;
    }
  
    teach() {
      console.log(`${this.name} is teaching.`);
    }
  }
  
  class University {
    students: Student[] = [];
    teachers: Teacher[] = [];
    section: string;
    classTiming: string;
  
    constructor(section: string, classTiming: string) {
      this.section = section;
      this.classTiming = classTiming;
    }
  
    enrollStudent(student: Student) {
      this.students.push(student);
    }
  
    hireTeacher(teacher: Teacher) {
      this.teachers.push(teacher);
    }
  
    displayUniversityInfo() {
      console.log(`University Section: ${this.section}`);
      console.log(`Class Timing: ${this.classTiming}`);
      console.log(`Number of Students: ${this.students.length}`);
      console.log(`Number of Teachers: ${this.teachers.length}`);
    }
  }
  
  // Usage example:
  const student1 = new Student("Ali", 20, 101);
  const student2 = new Student("Huzaifa", 22, 102);
  const teacher1 = new Teacher("Professor Bilal", 35, 201);
  
  const myUniversity = new University("A101", "9:00 AM - 11:00 AM");
  
  myUniversity.enrollStudent(student1);
  myUniversity.enrollStudent(student2);
  myUniversity.hireTeacher(teacher1);
  
  myUniversity.displayUniversityInfo();
  student1.introduce();
  student1.study();
  teacher1.introduce();
  teacher1.teach();