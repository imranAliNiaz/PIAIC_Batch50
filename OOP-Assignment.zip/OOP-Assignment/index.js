"use strict";
class Person {
    constructor(name, age) {
        this.name = name;
        this.age = age;
    }
    introduce() {
        console.log(`My name is ${this.name} and I am ${this.age} years old.`);
    }
}
class Student extends Person {
    constructor(name, age, studentID) {
        super(name, age);
        this.studentID = studentID;
    }
    study() {
        console.log(`${this.name} is studying.`);
    }
}
class Teacher extends Person {
    constructor(name, age, employeeID) {
        super(name, age);
        this.employeeID = employeeID;
    }
    teach() {
        console.log(`${this.name} is teaching.`);
    }
}
class University {
    constructor(section, classTiming) {
        this.students = [];
        this.teachers = [];
        this.section = section;
        this.classTiming = classTiming;
    }
    enrollStudent(student) {
        this.students.push(student);
    }
    hireTeacher(teacher) {
        this.teachers.push(teacher);
    }
    displayUniversityInfo() {
        console.log(`University Section: ${this.section}`);
        console.log(`Class Timing: ${this.classTiming}`);
        console.log(`Number of Students: ${this.students.length}`);
        console.log(`Number of Teachers: ${this.teachers.length}`);
    }
}
// Usage example:
const student1 = new Student("Ali", 20, 101);
const student2 = new Student("Huzaifa", 22, 102);
const teacher1 = new Teacher("Professor Bilal", 35, 201);
const myUniversity = new University("A101", "9:00 AM - 11:00 AM");
myUniversity.enrollStudent(student1);
myUniversity.enrollStudent(student2);
myUniversity.hireTeacher(teacher1);
myUniversity.displayUniversityInfo();
student1.introduce();
student1.study();
teacher1.introduce();
teacher1.teach();
